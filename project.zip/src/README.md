# Secure Software Engineering
# About The Project

This is how to run our Programming Paradigms project.

## Built With
All the dependencies of our project include:

* [Python 3.12.6](https://www.python.org/)
* [Django 5.1.1](https://www.djangoproject.com/)
* [Bootstrap v5.3](https://getbootstrap.com)

## Getting Started

To set up the project locally, download the ```src``` file from Gradescope:

### Prerequisites

There are no prerequisites required to run the project. No additional software needs to be installed (besides versions of Python, Django, and Bootstrap as mentioned above).

### Installation

To install and run this project, please follow the instructions below:

1. Set your given username and password as your temporary local environment variables. These credentials have been given by Prof. Santos.

	perform ```export USERN={your username}```
		and ```export PASSW={your password}```
   
     Your values of USERN and PASSW will be used within the code to acquire the API access-token.

3. Go into the ``` src/worndly``` directory

4. Run ```python3 manage.py runserver``` to start the website
