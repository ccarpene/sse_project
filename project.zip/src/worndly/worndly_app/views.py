from django.contrib.auth.hashers import make_password
from django.contrib.auth.hashers import check_password
from django.shortcuts import render
from .models import Player, GameResult, FailedLoginAttempt
from django.http import HttpResponseRedirect
from django.urls import reverse
import os
from django.utils import timezone
import random
from datetime import datetime, timedelta
from decimal import Decimal
from collections import Counter
import requests
import re

MAX_FAILED_ATTEMPTS = 5  # Max failed attempts before lockout
LOCKOUT_TIME = timedelta(minutes=15)  # Lockout time after too many failed attempts

# The API's URL for obtaining tokens
HOST = "https://jcssantos.pythonanywhere.com/"
i = 17 # group number
API_URL = f'group{i}/group{i}'
TOKEN_URL = HOST + '/api/token/'
VIEW_ALL_COINS = HOST + f'/api/{API_URL}/'
VIEW_USER_COINS = HOST + '/api/' + API_URL + '/player/{}/'
USER_PAY_COINS = HOST + '/api/' + API_URL + '/player/{}/pay'

# Credentials
username = os.environ.get("USERN")
password = os.environ.get("PASSW")
credentials = {
	"username": username, "password": password
}

# Create your views here.
def login(request):
        
    request.session['player_id'] = 0
    
    if request.method == 'POST':
    
        # Retrieve new user information
        username = request.POST.get('loginUsername')
        password = request.POST.get('loginPassword')

		# Retrieve the user from the database
        try:
        	current_player = Player.objects.get(username=username)
        except:
            # Invalid username
            return render(request, 'worndly_app/login.html', {'error_message_signin': 'Invalid login'})   
		
		# See how many current login attempts the user has
        failed_attempts = FailedLoginAttempt.objects.filter(user=current_player).first()

        if failed_attempts:
            time_since_last_failed_attempt = timezone.now() - failed_attempts.last_failed_attempt

			# If the user has at least 5 failed attempts and they are still locked out, do not let them sign in again
            if failed_attempts.failed_attempts >= MAX_FAILED_ATTEMPTS and time_since_last_failed_attempt < LOCKOUT_TIME:
                return render(request, 'worndly_app/login.html', {'error_message_signin': 'Account locked. Please try again later.'})

		# Check if the provided password matches the hashed password
        if check_password(password, current_player.password):
        	# Successful login, reset number of failed attempts
            if failed_attempts:
                failed_attempts.delete()

            request.session['player_id'] = current_player.id
            return HttpResponseRedirect(reverse('worndly_app:dashboard', args=(current_player.id,)))
        else:
            # Invalid password

			# Increment failed attempts count
            if failed_attempts:
                failed_attempts.failed_attempts += 1
                failed_attempts.save()
            else:
                FailedLoginAttempt.objects.create(user=current_player, failed_attempts=1)

            return render(request, 'worndly_app/login.html', {'error_message_signin': 'Invalid login'})   
 
    else:
        return render(request, 'worndly_app/login.html')
    
def sign_up(request):
    
    request.session['player_id'] = 0

    if request.method == 'POST':
    
        # Retrieve new user information
        name = request.POST.get('signUpName')
        username = request.POST.get('signUpUsername')
        password = request.POST.get('signUpPassword')
        email = request.POST.get('signUpEmail')

        # Test if the password is strong enough
        strong = bool(re.search('.*[0-9].*', password)) & bool(re.search('.*[A-Z].*', password)) & bool(re.search('.*[!@#$%\^&\*].*', password)) & (len(password) >= 10) 

        if not strong:
            return render(request, 'worndly_app/login.html', {'error_message_signin': 'Password must contain at least 10 characters, with at least 1 number, 1 symbol (!, @, #, $, %, ^, &, or *), and 1 capital letter.', 'name': name, 'username': username, 'password': password, 'email': email}) 
        
        # Create new user
        try:
            hashed_password = make_password(password)
            user = Player.objects.create(username=username, password=hashed_password, email=email)
            user.name = name
            user.save()
            request.session['player_id'] = user.id
        except:
            return render(request, 'worndly_app/login.html', {'error_message_signin': 'Username already taken', 'name': name, 'username': username, 'password': password, 'email': email}) 

        # With a valid user signup, go to their dashboard
        return HttpResponseRedirect(reverse('worndly_app:dashboard', args=(user.id,)))

    else:
        return render(request, 'worndly_app/login.html')

def dashboard(request, pk):

    player_id = request.session.get('player_id')
    
    # Bring up the appropriate user, else go back to login
    try:
        user = Player.objects.get(pk=pk)

		# Prevent users from web parameter tampering, make sure the user has logged in first
        if player_id is not user.id:
            player_id = 0
            return HttpResponseRedirect(reverse('worndly_app:login'))
    except:
        return render(request, 'worndly_app/login.html')

    all_results = GameResult.objects.filter(user=user).order_by('-game_date')

    # Calculate win frequency
    total_games = all_results.count()
    win_count = all_results.filter(pass_fail=True).count()
    win_frequency = win_count / total_games * 100 if total_games != 0 else 0
    win_frequency = round(win_frequency, 2)

    # Calculate distribution
    attempts_distribution = Counter(all_results.values_list('attempts', flat=True))
    attempts_distribution = dict(attempts_distribution)
    attempts = []
    for num in range(6):
        attempts.append(attempts_distribution.get(num+1, 0))

    # Gather info about the user to display to the dashboard
    context = {
        'user': user,
        'win_frequency': win_frequency,
        'attempts_distribution': attempts,
        'total_games': total_games
        }

    return render(request, 'worndly_app/dashboard.html', context)

def display_results(request, pk):
    
    player_id = request.session.get('player_id')
    
    # Bring up the appropriate user, else go back to login
    try:
        user = Player.objects.get(pk=pk)

		# Prevent users from web parameter tampering, make sure the user has logged in first
        if player_id is not user.id:
            player_id = 0
            return HttpResponseRedirect(reverse('worndly_app:login'))
    except:
        return render(request, 'worndly_app/login.html')
	
    filter_option = request.GET.get('filter', 'all')

    # Find the game results depending on the time filter the user applied
    if filter_option == 'last_week':
        end_date = timezone.now().date()
        start_date = end_date-timedelta(days=6)
        game_results = GameResult.objects.filter(user=user, game_date__range=(start_date, end_date)).order_by('-game_date')
    elif filter_option == 'last_month':
        end_date = timezone.now().date()
        start_date = end_date - timedelta(days=30)
        game_results = GameResult.objects.filter(user=user, game_date__range=(start_date, end_date)).order_by('-game_date')
    elif filter_option == 'last_year':
        end_date = timezone.now().date()
        start_date = end_date.replace(year=end_date.year - 1)
        game_results = GameResult.objects.filter(user=user, game_date__range=(start_date, end_date)).order_by('-game_date')
    else:
        game_results = GameResult.objects.filter(user=user).order_by('-game_date')
    
    all_results = GameResult.objects.filter(user=user).order_by('-game_date')

    # Calculate win frequency
    total_games = all_results.count()
    win_count = all_results.filter(pass_fail=True).count()
    win_frequency = win_count / total_games * 100 if total_games != 0 else 0
    win_frequency = round(win_frequency, 2)

    # Calculate distribution
    attempts_distribution = Counter(all_results.values_list('attempts', flat=True))
    attempts_distribution = dict(attempts_distribution)
    attempts = []
    for num in range(6):
        attempts.append(attempts_distribution.get(num+1, 0))
        

    # Gather info about the user to display in the game statistics distribution
    context = {
        'user': user,
        'game_results': game_results,
        'filter_option': filter_option,
        'win_frequency': win_frequency,
        'attempts_distribution': attempts,
        'total_games': total_games
    }
    return render(request, 'worndly_app/dashboard.html', context)

def gameplay(request, pk):
    
    player_id = request.session.get('player_id')
    
    # Bring up the appropriate user, else go back to login
    try:
        user = Player.objects.get(pk=pk)

		# Prevent users from web parameter tampering, make sure the user has logged in first
        if player_id is not user.id:
            player_id = 0
            return HttpResponseRedirect(reverse('worndly_app:login'))
    except:
        return render(request, 'worndly_app/login.html')
	
	
    request.session.pop('previous_guesses', None) #reset the session variables
    request.session.pop('previous_guesses_original', None) #reset session variables
    context = {
            'user': user
            }

    return render(request, 'worndly_app/gameplay.html', context)

def choose_word(request, pk):
    
    player_id = request.session.get('player_id')
    
    # Bring up the appropriate user, else go back to login
    try:
        user = Player.objects.get(pk=pk)

		# Prevent users from web parameter tampering, make sure the user has logged in first
        if player_id is not user.id:
            player_id = 0
            return HttpResponseRedirect(reverse('worndly_app:login'))
    except:
        return render(request, 'worndly_app/login.html')
	
	
    #function to randomly choose a word when they choose a language to start the game
    request.session['language'] = None #reset the session variable
    language = request.GET.get('language') #get the language that they chose

    today = datetime.now().date() #todays date (to check if they already played 3 times)

    # find out how many games they have played today
    games_today = GameResult.objects.filter(user=user, game_date=today).count()
    # find out how many purchased games the user has
    purchased_games = Player.objects.get(username=user.username).purchased_games

    # check if user has exceeded their daily plays
    if games_today >= 3: # if the user has purchased games available, bypass this and let them play
        if user.purchased_games == 0: # otherwise, can't play today. redirect them to buy more games
            return HttpResponseRedirect(reverse('worndly_app:buy_games', args=(user.id, )))

    # access the correct language file
    file_path = os.path.join(os.path.dirname(__file__), '..','..', 'words', f'{language}.txt')

    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            words = file.readlines()
            random_word = random.choice(words).strip().lower() #random word!

            print(random_word) #print to console for testing purposes
            context = {
                    'user': user,
                    'word': random_word,
                    'language': language
                    }
            request.session['language'] = language #store the language so it can be accessed later

            # if exceeded daily play, then they are using a purchased game, so account for that 
            if games_today >= 3:
                user.purchased_games -= 1
                user.save()
            
            return render(request, 'worndly_app/gameplay.html', context)
    except FileNotFoundError:
        return render(request, 'worndly_app/gameplay.html', {'error_message_gameplay': 'language file not found'}) 

def check_guess(request, pk):
    
    player_id = request.session.get('player_id')
    
    # Bring up the appropriate user, else go back to login
    try:
        user = Player.objects.get(pk=pk)

		# Prevent users from web parameter tampering, make sure the user has logged in first
        if player_id is not user.id:
            player_id = 0
            return HttpResponseRedirect(reverse('worndly_app:login'))
    except:
        return render(request, 'worndly_app/login.html')
	
    #function to check their guess when they submit a guess

    if request.method == 'POST':
        word = request.POST.get('word') #get the word
        guess = request.POST.get('guess') #get the guess
    
        previous_guesses = request.session.get('previous_guesses', []) # get the previous guesses for the round
        previous_guesses_original = request.session.get('previous_guesses_original', [])
        attempts_remaining = 5 - len(previous_guesses) #attempts after the current attempt

        language = request.session.get('language') #access the language to verify if their guess is in the txt file
        file_path = os.path.join(os.path.dirname(__file__), '..', '..', 'words', f'{language}.txt')

        with open(file_path, 'r', encoding='utf-8') as file:
            words = file.readlines()
            words = [word.strip().lower() for word in words]
            if guess.lower() not in words:
                #INVALID GUESS
                return render(request, 'worndly_app/gameplay.html', {'word': word, 'error': 'Invalid Guess: Try Again', 'attempts_remaining': attempts_remaining+1, 'user': user, 'previous_guesses': previous_guesses})

        #store the colors of each letter of the guess
        feedback_colors = []
        word_counter = Counter(word)

        for i in range(5):
            if guess[i] == word[i]:
                feedback_colors.append('#63c9a2')
                word_counter[guess[i]] -= 1
            elif guess[i] in word_counter and word_counter[guess[i]] > 0:
                feedback_colors.append('#e8db87')
                word_counter[guess[i]] -= 1  # Decrement count for matched letter
            else:
                feedback_colors.append('darkgray')
        zipped_feedback = zip(feedback_colors, guess) #store the colors with each corresponding letter

        add = list(zipped_feedback)

        #check if they already guessed the word
        if guess in previous_guesses_original:
            return render(request, 'worndly_app/gameplay.html', {'word': word, 'error': 'Word Already Guessed: Try Again', 'attempts_remaining': attempts_remaining+1, 'user': user, 'previous_guesses': previous_guesses})
        previous_guesses_original.append(guess)
        previous_guesses.append(add) #add to their previous guesses

        request.session['previous_guesses'] = previous_guesses
        request.session['previous_guesses_original'] = previous_guesses_original

        #check if they guessed correctly
        if guess == word:
            attempts_taken = len(previous_guesses)
            if attempts_taken <= 6:
                # guessed correctly - display congratulations
                message = f"Congratulations! You won in {attempts_taken} attempts. The word was '{word}'."
                pass_fail = 1
            else:
                message = f"Sorry, you lost. The word was '{word}'."
                pass_fail = 0
        elif len(previous_guesses) >= 6:
            #ran out of attempts - tell them the correct word
            message = f"Sorry, you lost. The word was '{word}'."
            pass_fail = 0

        else:
            #still have guesses left
            return render(request, 'worndly_app/gameplay.html', {'word': word,  'attempts_remaining': attempts_remaining, 'previous_guesses': previous_guesses, 'user': user})

        attempts_taken = len(previous_guesses)
        game_date = datetime.now().date()
        game_result = GameResult.objects.create(user=user, game_date=game_date, pass_fail=pass_fail, attempts=attempts_taken) #store the information in database

        request.session.pop('previous_guesses', None)
        return render(request, 'worndly_app/gameplay.html', {'word': word, 'message': message, 'user': user}) 


def buy_games(request, pk):
    
    player_id = request.session.get('player_id')
    
    # Bring up the appropriate user, else go back to login
    try:
        user = Player.objects.get(pk=pk)

		# Prevent users from web parameter tampering, make sure the user has logged in first
        if player_id is not user.id:
            player_id = 0
            return HttpResponseRedirect(reverse('worndly_app:login'))
    except:
        return render(request, 'worndly_app/login.html')
    
    access_token = get_token(credentials)
    coins = view_balance_for_user(access_token, user.email)
    if not coins:
        context = {'user':user}
        return render(request, 'worndly_app/buy_more_games.html', context)
    context = {
            'user': user,
            'coins': coins['amount']
            }
    return render(request, 'worndly_app/buy_more_games.html', context)

def make_purchase(request, pk):
    
    player_id = request.session.get('player_id')
    
    # Bring up the appropriate user, else go back to login
    try:
        user = Player.objects.get(pk=pk)

		# Prevent users from web parameter tampering, make sure the user has logged in first
        if player_id is not user.id:
            player_id = 0
            return HttpResponseRedirect(reverse('worndly_app:login'))
    except:
        return render(request, 'worndly_app/login.html')

    purchase_amount = int(request.GET.get('number')) # get the purchase request amount from the html input box
    access_token = get_token(credentials)
    coins = view_balance_for_user(access_token, user.email) # use API to get their coin balance
    if not coins: # if user does not have a coin balance in the REST server, make no purchase and redirect them
        return HttpResponseRedirect(reverse('worndly_app:buy_games', args=(user.id, )))
    coins = coins['amount']
    # update info
    user.coin_balance = coins
    user.save()
    new_balance = coins-purchase_amount
    context = {
            'user': user,
            'purchase_amount':purchase_amount,
            'coins_old':coins,
            'coins_new':new_balance
            }
    if purchase_amount == 0: # user selected 0 on the input box, do not continue
        return HttpResponseRedirect(reverse('worndly_app:buy_games', args=(user.id, )))
    else: # else they had to have selected a valid coin amount they own, so use API and perform the purchase
        user_pay(TOKEN, user.email, purchase_amount)
        # update the database of user's purchased_games attribute to reflect the amount they just purchased
        user.purchased_games += purchase_amount
        user.coin_balance -= purchase_amount 
        user.save()

    return render(request, 'worndly_app/make_purchase.html', context)


def view_all_coins(access_token):
	
   # Use the access token to make an authenticated request
   headers = {
       'Authorization': f'Bearer {access_token}'
   }

   # Make a GET request with the authorization header
   api_response = requests.get(VIEW_ALL_COINS, headers=headers)

   if api_response.status_code == 200:
       # Process the data from the API
       return api_response.json()
   else:
       print("Failed to access the API endpoint to view all coins:", api_response.status_code)


def view_balance_for_user(access_token, email):
	
   # Use the access token to make an authenticated request
   headers = {
       'Authorization': f'Bearer {access_token}'
   }

   # Make a GET request with the authorization header
   api_response = requests.get(VIEW_USER_COINS.format(email), headers=headers)

   if api_response.status_code == 200:
       # Process the data from the API
       return api_response.json()
   else:
       print("Failed to access the API endpoint to view balance for user:", api_response.status_code)

def get_token(credentials):
	
    # Make a POST request to obtain API token
    response = requests.post(TOKEN_URL, data=credentials)

    # Check if the request was successful
    if response.status_code == 200:
        # Extract the access token from the response
        token_data = response.json()
        access_token = token_data['access']
        return access_token

        # if we reach here, we could not get token
    print("Failed to obtain token:", response.status_code)

def user_pay(access_token, email, amount):
	
   # Use the access token to make an authenticated request
   headers = {
       'Authorization': f'Bearer {access_token}'
   }
   data = {"amount": amount} # non-negative integer value to be decreased
   # Make a POST request with the authorization header and data payload
   api_response = requests.post(USER_PAY_COINS.format(email), headers=headers, data=data)

   if api_response.status_code == 200:
       # Process the data from the API
       return api_response.json()
   else:
       print("Failed to access the API endpoint to pay:", api_response.status_code)


def logout(request):
    
    player_id = request.session.get('player_id')
    
    # Bring up the appropriate user, else go back to login
    try:
        user = Player.objects.get(pk=pk)

		# Prevent users from web parameter tampering, make sure the user has logged in first
        if player_id is not user.id:
            player_id = 0
            return HttpResponseRedirect(reverse('worndly_app:login'))
    except:
        player_id = 0
        return render(request, 'worndly_app/login.html')

