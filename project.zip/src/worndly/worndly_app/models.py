from django.db import models

# Create your models here.
class Player(models.Model):
    # Model to store player information
    name = models.CharField(max_length=200)
    username = models.CharField(max_length=200, unique=True)
    email = models.CharField(max_length=100)
    password = models.CharField(max_length=200)
    coin_balance = models.IntegerField(default=10)
    purchased_games = models.IntegerField(default=0) # how many purchased games you have

class GameResult(models.Model):
    # Model to store the game results to be used for the dashboard in feature 3
    user = models.ForeignKey(Player, on_delete=models.CASCADE)
    game_date = models.DateField() # the date of the game
    pass_fail = models.BooleanField() # 1 if you were successful, 0 if not
    attempts = models.IntegerField() # how many tries it took you

# New model to check for how many failed login attempts
class FailedLoginAttempt(models.Model):
    user = models.ForeignKey(Player, on_delete=models.CASCADE)
    failed_attempts = models.IntegerField(default=0)
    last_failed_attempt = models.DateTimeField(auto_now=True)
