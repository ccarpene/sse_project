from django.contrib import admin

# Register your models here.
from .models import Player
from .models import GameResult

admin.site.register(GameResult)
admin.site.register(Player)
