from django.urls import path
from . import views

app_name = 'worndly_app'
urlpatterns = [
    path('', views.login, name="login"),
    path('signup/', views.sign_up, name="sign_up"),
    path('<int:pk>/dashboard/', views.dashboard, name="dashboard"),
    path('<int:pk>/dashboard/display_results/', views.display_results, name="display_results"),
    path('<int:pk>/gameplay/', views.gameplay, name="gameplay"),
    path('<int:pk>/choose_word/', views.choose_word, name='choose_word'),
    path('<int:pk>/check_guess/', views.check_guess, name='check_guess'),
    path('<int:pk>/buy_games/', views.buy_games, name='buy_games'),
    path('<int:pk>/make_purchase/', views.make_purchase, name='make_purchase'),
    path('logout/', views.logout, name='logout')
]
